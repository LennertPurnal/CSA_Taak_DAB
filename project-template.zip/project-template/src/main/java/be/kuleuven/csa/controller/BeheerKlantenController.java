package be.kuleuven.csa.controller;

public class BeheerKlantenController {

    public void initialize() {

    }
}
