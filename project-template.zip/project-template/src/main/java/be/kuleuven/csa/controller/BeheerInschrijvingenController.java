package be.kuleuven.csa.controller;

public class BeheerInschrijvingenController {

    public void initialize() {

    }
}
