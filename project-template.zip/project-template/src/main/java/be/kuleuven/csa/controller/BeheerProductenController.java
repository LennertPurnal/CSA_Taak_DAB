package be.kuleuven.csa.controller;

public class BeheerProductenController {

    public void initialize() {

    }
}
